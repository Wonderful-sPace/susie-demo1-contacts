package com.example.susie_demo1_contacts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SusieDemo1ContactsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SusieDemo1ContactsApplication.class, args);
	}

}
