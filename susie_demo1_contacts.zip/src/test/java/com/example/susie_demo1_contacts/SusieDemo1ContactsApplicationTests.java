package com.example.susie_demo1_contacts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SusieDemo1ContactsApplicationTests {

	@Test
	void contextLoads() {
	}

}
